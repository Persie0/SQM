Unzip the firmware file and look at the folder "Required Libraries"
There should be TEN folders


Copy these TEN folders to the Arduino\libraries folder in your Documents folder (for windows). Replace any existing folders or files.

Do not edit or replace any of these files. They have been edited and modified to use with the mySQMPRO firmware.
